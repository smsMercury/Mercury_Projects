Public Class COutputProps

    Private mXmlPath As String = ""
    Private mOutputPath As String = ""
    Private mOutputFile As String = ""
    Private mMsgList As New ArrayList
    Private mSourceList As New ArrayList
    Private mFilterPortStr As String = ""
    Private mFilterTypeStr As String = ""
    Private mCmuRfosHdrScript As String = ""
    Private mNcctHdrScript As String = ""

    Public Property XmlPath() As String
        Get
            Return mXmlPath
        End Get
        Set(ByVal value As String)
            mXmlPath = value
        End Set
    End Property

    Public Property OutputPath() As String
        Get
            Return mOutputPath
        End Get
        Set(ByVal value As String)
            mOutputPath = value
        End Set
    End Property

    Public Property OutputFile() As String
        Get
            Return mOutputFile
        End Get
        Set(ByVal value As String)
            mOutputFile = value
        End Set
    End Property

    Public Property MsgList() As ArrayList
        Get
            Return mMsgList
        End Get
        Set(ByVal value As ArrayList)
            mMsgList = value
        End Set
    End Property

    Public Property SourceList() As ArrayList
        Get
            Return mSourceList
        End Get
        Set(ByVal value As ArrayList)
            mSourceList = value
        End Set
    End Property

    Public Property FilterPortString() As String
        Get
            Return mFilterPortStr
        End Get
        Set(ByVal value As String)
            mFilterPortStr = value
        End Set
    End Property

    Public Property FilterTypeString() As String
        Get
            Return mFilterTypeStr
        End Get
        Set(ByVal value As String)
            mFilterTypeStr = value
        End Set
    End Property

    Public Property CmuRfosHdrScript() As String
        Get
            Return mCmuRfosHdrScript
        End Get
        Set(ByVal value As String)
            mCmuRfosHdrScript = value
        End Set
    End Property

    Public Property NcctHdrScript() As String
        Get
            Return mNcctHdrScript
        End Get
        Set(ByVal value As String)
            mNcctHdrScript = value
        End Set
    End Property
End Class
