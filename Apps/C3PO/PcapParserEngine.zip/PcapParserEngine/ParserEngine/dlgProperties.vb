Imports System.Windows.Forms

Public Class dlgProperties

    Private mXmlPath As String = ""
    Private mCmuRfosHdr As String = ""
    Private mNcctHdr As String = ""
    Private mPropPath As String = ""

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click

        If mPropPath <> "" Then
            Dim wtr As New IO.StreamWriter(mPropPath)
            wtr.WriteLine(mXmlPath)
            wtr.WriteLine(mCmuRfosHdr)
            wtr.WriteLine(mNcctHdr)
            wtr.Close()
        End If
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub btnBrwse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrwseScriptsDir.Click
        Dim dlg As New FolderBrowserDialog

        dlg.SelectedPath = "c:\Mercury"
        If dlg.ShowDialog = Windows.Forms.DialogResult.OK Then
            'save path
            XmlPath = dlg.SelectedPath
            Me.TextBox1.Text = XmlPath
        End If
    End Sub

    Private Sub btnBrowseCmuRfosHdr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseCmuRfosHdr.Click
        Dim dlg As New OpenFileDialog

        dlg.InitialDirectory = "c:\Mercury"
        dlg.Filter = "Cmu/Rfos header script (*.xml)|*.xml"
        If dlg.ShowDialog = Windows.Forms.DialogResult.OK Then
            CmuRfosHdr = dlg.FileName
            Me.tbCmuRfosHdr.Text = CmuRfosHdr
        End If
    End Sub

    Private Sub btnBrowseNcctHdr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseNcctHdr.Click
        Dim dlg As New OpenFileDialog

        dlg.InitialDirectory = "c:\Mercury"
        dlg.Filter = "Ncct header script (*.xml)|*.xml"
        If dlg.ShowDialog = Windows.Forms.DialogResult.OK Then
            NcctHdr = dlg.FileName
            Me.tbNcctHdr.Text = NcctHdr
        End If
    End Sub

    Public Property XmlPath() As String
        Get
            Return mXmlPath
        End Get
        Set(ByVal value As String)
            mXmlPath = value
            Me.TextBox1.Text = mXmlPath
        End Set
    End Property

    Public Property CmuRfosHdr() As String
        Get
            Return mCmuRfosHdr
        End Get
        Set(ByVal value As String)
            mCmuRfosHdr = value
            Me.tbCmuRfosHdr.Text = value
        End Set
    End Property

    Public Property NcctHdr() As String
        Get
            Return mNcctHdr
        End Get
        Set(ByVal value As String)
            mNcctHdr = value
            Me.tbNcctHdr.Text = value
        End Set
    End Property

    Public WriteOnly Property PropPath() As String
        Set(ByVal value As String)
            mPropPath = value
        End Set
    End Property


End Class
