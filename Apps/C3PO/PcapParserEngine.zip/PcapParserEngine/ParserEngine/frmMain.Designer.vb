<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.btnProcData = New System.Windows.Forms.Button
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PropertiesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.clbSelectedMsgs = New System.Windows.Forms.CheckedListBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.rbArchive = New System.Windows.Forms.RadioButton
        Me.rbPcap = New System.Windows.Forms.RadioButton
        Me.btnBrowseSources = New System.Windows.Forms.Button
        Me.lbSources = New System.Windows.Forms.ListBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.bBrowseOutput = New System.Windows.Forms.Button
        Me.tbOutputPath = New System.Windows.Forms.TextBox
        Me.lOutputType = New System.Windows.Forms.Label
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.rbLink16 = New System.Windows.Forms.RadioButton
        Me.rbNcct = New System.Windows.Forms.RadioButton
        Me.rbRfos = New System.Windows.Forms.RadioButton
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar
        Me.lblFile = New System.Windows.Forms.Label
        Me.cmnuMessages = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.SelectAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ClearAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LoadProfileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FilenameToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.rbNoMsg = New System.Windows.Forms.RadioButton
        Me.rbAllMsg = New System.Windows.Forms.RadioButton
        Me.rbSelectMsg = New System.Windows.Forms.RadioButton
        Me.MenuStrip1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.cmnuMessages.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnProcData
        '
        Me.btnProcData.Location = New System.Drawing.Point(468, 572)
        Me.btnProcData.Margin = New System.Windows.Forms.Padding(2)
        Me.btnProcData.Name = "btnProcData"
        Me.btnProcData.Size = New System.Drawing.Size(102, 32)
        Me.btnProcData.TabIndex = 5
        Me.btnProcData.Text = "Process Data"
        Me.btnProcData.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.PropertiesToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(4, 2, 0, 2)
        Me.MenuStrip1.Size = New System.Drawing.Size(604, 24)
        Me.MenuStrip1.TabIndex = 6
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(92, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'PropertiesToolStripMenuItem
        '
        Me.PropertiesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EditToolStripMenuItem})
        Me.PropertiesToolStripMenuItem.Name = "PropertiesToolStripMenuItem"
        Me.PropertiesToolStripMenuItem.Size = New System.Drawing.Size(72, 20)
        Me.PropertiesToolStripMenuItem.Text = "Properties"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(94, 22)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.clbSelectedMsgs)
        Me.GroupBox2.Location = New System.Drawing.Point(17, 35)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Size = New System.Drawing.Size(563, 230)
        Me.GroupBox2.TabIndex = 7
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Select Messages"
        '
        'clbSelectedMsgs
        '
        Me.clbSelectedMsgs.CheckOnClick = True
        Me.clbSelectedMsgs.FormattingEnabled = True
        Me.clbSelectedMsgs.HorizontalScrollbar = True
        Me.clbSelectedMsgs.Location = New System.Drawing.Point(10, 17)
        Me.clbSelectedMsgs.Margin = New System.Windows.Forms.Padding(2)
        Me.clbSelectedMsgs.MultiColumn = True
        Me.clbSelectedMsgs.Name = "clbSelectedMsgs"
        Me.clbSelectedMsgs.Size = New System.Drawing.Size(543, 199)
        Me.clbSelectedMsgs.Sorted = True
        Me.clbSelectedMsgs.TabIndex = 1
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.rbArchive)
        Me.GroupBox3.Controls.Add(Me.rbPcap)
        Me.GroupBox3.Controls.Add(Me.btnBrowseSources)
        Me.GroupBox3.Controls.Add(Me.lbSources)
        Me.GroupBox3.Location = New System.Drawing.Point(17, 269)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox3.Size = New System.Drawing.Size(286, 295)
        Me.GroupBox3.TabIndex = 8
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Select Data Sources"
        '
        'rbArchive
        '
        Me.rbArchive.AutoSize = True
        Me.rbArchive.Enabled = False
        Me.rbArchive.Location = New System.Drawing.Point(13, 271)
        Me.rbArchive.Name = "rbArchive"
        Me.rbArchive.Size = New System.Drawing.Size(96, 17)
        Me.rbArchive.TabIndex = 5
        Me.rbArchive.Text = "Parse Archives"
        Me.rbArchive.UseVisualStyleBackColor = True
        '
        'rbPcap
        '
        Me.rbPcap.AutoSize = True
        Me.rbPcap.Checked = True
        Me.rbPcap.Location = New System.Drawing.Point(13, 252)
        Me.rbPcap.Name = "rbPcap"
        Me.rbPcap.Size = New System.Drawing.Size(88, 17)
        Me.rbPcap.TabIndex = 4
        Me.rbPcap.TabStop = True
        Me.rbPcap.Text = "Parse PCAPs"
        Me.rbPcap.UseVisualStyleBackColor = True
        '
        'btnBrowseSources
        '
        Me.btnBrowseSources.Location = New System.Drawing.Point(170, 246)
        Me.btnBrowseSources.Margin = New System.Windows.Forms.Padding(2)
        Me.btnBrowseSources.Name = "btnBrowseSources"
        Me.btnBrowseSources.Size = New System.Drawing.Size(103, 23)
        Me.btnBrowseSources.TabIndex = 3
        Me.btnBrowseSources.Text = "Browse Sources"
        Me.btnBrowseSources.UseVisualStyleBackColor = True
        '
        'lbSources
        '
        Me.lbSources.FormattingEnabled = True
        Me.lbSources.HorizontalScrollbar = True
        Me.lbSources.Location = New System.Drawing.Point(13, 17)
        Me.lbSources.Margin = New System.Windows.Forms.Padding(2)
        Me.lbSources.Name = "lbSources"
        Me.lbSources.Size = New System.Drawing.Size(260, 225)
        Me.lbSources.Sorted = True
        Me.lbSources.TabIndex = 2
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.bBrowseOutput)
        Me.GroupBox1.Controls.Add(Me.tbOutputPath)
        Me.GroupBox1.Controls.Add(Me.lOutputType)
        Me.GroupBox1.Location = New System.Drawing.Point(308, 269)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(272, 97)
        Me.GroupBox1.TabIndex = 9
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Select Output Type"
        '
        'bBrowseOutput
        '
        Me.bBrowseOutput.Location = New System.Drawing.Point(204, 62)
        Me.bBrowseOutput.Margin = New System.Windows.Forms.Padding(2)
        Me.bBrowseOutput.Name = "bBrowseOutput"
        Me.bBrowseOutput.Size = New System.Drawing.Size(58, 22)
        Me.bBrowseOutput.TabIndex = 6
        Me.bBrowseOutput.Text = "Browse"
        Me.bBrowseOutput.UseVisualStyleBackColor = True
        '
        'tbOutputPath
        '
        Me.tbOutputPath.Location = New System.Drawing.Point(10, 38)
        Me.tbOutputPath.Margin = New System.Windows.Forms.Padding(2)
        Me.tbOutputPath.Name = "tbOutputPath"
        Me.tbOutputPath.Size = New System.Drawing.Size(252, 20)
        Me.tbOutputPath.TabIndex = 5
        '
        'lOutputType
        '
        Me.lOutputType.AutoSize = True
        Me.lOutputType.Location = New System.Drawing.Point(95, 23)
        Me.lOutputType.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lOutputType.Name = "lOutputType"
        Me.lOutputType.Size = New System.Drawing.Size(63, 13)
        Me.lOutputType.TabIndex = 4
        Me.lOutputType.Text = "Output path"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.rbLink16)
        Me.GroupBox4.Controls.Add(Me.rbNcct)
        Me.GroupBox4.Controls.Add(Me.rbRfos)
        Me.GroupBox4.Location = New System.Drawing.Point(308, 460)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox4.Size = New System.Drawing.Size(272, 104)
        Me.GroupBox4.TabIndex = 10
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Filter by Port"
        '
        'rbLink16
        '
        Me.rbLink16.AutoSize = True
        Me.rbLink16.Location = New System.Drawing.Point(10, 62)
        Me.rbLink16.Margin = New System.Windows.Forms.Padding(2)
        Me.rbLink16.Name = "rbLink16"
        Me.rbLink16.Size = New System.Drawing.Size(141, 17)
        Me.rbLink16.TabIndex = 3
        Me.rbLink16.Text = "7000 - Link16 Messages"
        Me.rbLink16.UseVisualStyleBackColor = True
        '
        'rbNcct
        '
        Me.rbNcct.AutoSize = True
        Me.rbNcct.Location = New System.Drawing.Point(10, 42)
        Me.rbNcct.Margin = New System.Windows.Forms.Padding(2)
        Me.rbNcct.Name = "rbNcct"
        Me.rbNcct.Size = New System.Drawing.Size(132, 17)
        Me.rbNcct.TabIndex = 2
        Me.rbNcct.Text = "6002 - Ncct Messages"
        Me.rbNcct.UseVisualStyleBackColor = True
        '
        'rbRfos
        '
        Me.rbRfos.AutoSize = True
        Me.rbRfos.Checked = True
        Me.rbRfos.Location = New System.Drawing.Point(10, 21)
        Me.rbRfos.Margin = New System.Windows.Forms.Padding(2)
        Me.rbRfos.Name = "rbRfos"
        Me.rbRfos.Size = New System.Drawing.Size(131, 17)
        Me.rbRfos.TabIndex = 1
        Me.rbRfos.TabStop = True
        Me.rbRfos.Text = "7577 - Rfos Messages"
        Me.rbRfos.UseVisualStyleBackColor = True
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(17, 576)
        Me.ProgressBar1.Margin = New System.Windows.Forms.Padding(2)
        Me.ProgressBar1.Maximum = 1000
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(431, 22)
        Me.ProgressBar1.TabIndex = 11
        '
        'lblFile
        '
        Me.lblFile.AutoSize = True
        Me.lblFile.Location = New System.Drawing.Point(18, 602)
        Me.lblFile.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFile.Name = "lblFile"
        Me.lblFile.Size = New System.Drawing.Size(67, 13)
        Me.lblFile.TabIndex = 12
        Me.lblFile.Text = "File Progress"
        '
        'cmnuMessages
        '
        Me.cmnuMessages.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SelectAllToolStripMenuItem, Me.ClearAllToolStripMenuItem, Me.LoadProfileToolStripMenuItem})
        Me.cmnuMessages.Name = "cmnuMessages"
        Me.cmnuMessages.Size = New System.Drawing.Size(138, 70)
        '
        'SelectAllToolStripMenuItem
        '
        Me.SelectAllToolStripMenuItem.Name = "SelectAllToolStripMenuItem"
        Me.SelectAllToolStripMenuItem.Size = New System.Drawing.Size(137, 22)
        Me.SelectAllToolStripMenuItem.Text = "Select All"
        '
        'ClearAllToolStripMenuItem
        '
        Me.ClearAllToolStripMenuItem.Name = "ClearAllToolStripMenuItem"
        Me.ClearAllToolStripMenuItem.Size = New System.Drawing.Size(137, 22)
        Me.ClearAllToolStripMenuItem.Text = "Clear All"
        '
        'LoadProfileToolStripMenuItem
        '
        Me.LoadProfileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FilenameToolStripMenuItem})
        Me.LoadProfileToolStripMenuItem.Name = "LoadProfileToolStripMenuItem"
        Me.LoadProfileToolStripMenuItem.Size = New System.Drawing.Size(137, 22)
        Me.LoadProfileToolStripMenuItem.Text = "Load Profile"
        '
        'FilenameToolStripMenuItem
        '
        Me.FilenameToolStripMenuItem.Name = "FilenameToolStripMenuItem"
        Me.FilenameToolStripMenuItem.Size = New System.Drawing.Size(122, 22)
        Me.FilenameToolStripMenuItem.Text = "Filename"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.rbNoMsg)
        Me.GroupBox5.Controls.Add(Me.rbAllMsg)
        Me.GroupBox5.Controls.Add(Me.rbSelectMsg)
        Me.GroupBox5.Location = New System.Drawing.Point(308, 371)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(272, 84)
        Me.GroupBox5.TabIndex = 14
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Table of Contents"
        '
        'rbNoMsg
        '
        Me.rbNoMsg.AutoSize = True
        Me.rbNoMsg.Location = New System.Drawing.Point(10, 60)
        Me.rbNoMsg.Name = "rbNoMsg"
        Me.rbNoMsg.Size = New System.Drawing.Size(115, 17)
        Me.rbNoMsg.TabIndex = 2
        Me.rbNoMsg.TabStop = True
        Me.rbNoMsg.Text = "No TOC Messages"
        Me.rbNoMsg.UseVisualStyleBackColor = True
        '
        'rbAllMsg
        '
        Me.rbAllMsg.AutoSize = True
        Me.rbAllMsg.Checked = True
        Me.rbAllMsg.Location = New System.Drawing.Point(10, 19)
        Me.rbAllMsg.Name = "rbAllMsg"
        Me.rbAllMsg.Size = New System.Drawing.Size(87, 17)
        Me.rbAllMsg.TabIndex = 1
        Me.rbAllMsg.TabStop = True
        Me.rbAllMsg.Text = "All Messages"
        Me.rbAllMsg.UseVisualStyleBackColor = True
        '
        'rbSelectMsg
        '
        Me.rbSelectMsg.AutoSize = True
        Me.rbSelectMsg.Location = New System.Drawing.Point(10, 38)
        Me.rbSelectMsg.Name = "rbSelectMsg"
        Me.rbSelectMsg.Size = New System.Drawing.Size(142, 17)
        Me.rbSelectMsg.TabIndex = 0
        Me.rbSelectMsg.Text = "Selected Messages Only"
        Me.rbSelectMsg.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(604, 634)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.lblFile)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnProcData)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Compass Call Communications Parser (CCCP)"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.cmnuMessages.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnProcData As System.Windows.Forms.Button
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PropertiesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents clbSelectedMsgs As System.Windows.Forms.CheckedListBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents btnBrowseSources As System.Windows.Forms.Button
    Friend WithEvents lbSources As System.Windows.Forms.ListBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents bBrowseOutput As System.Windows.Forms.Button
    Friend WithEvents tbOutputPath As System.Windows.Forms.TextBox
    Friend WithEvents lOutputType As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents rbLink16 As System.Windows.Forms.RadioButton
    Friend WithEvents rbNcct As System.Windows.Forms.RadioButton
    Friend WithEvents rbRfos As System.Windows.Forms.RadioButton
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents lblFile As System.Windows.Forms.Label
    Friend WithEvents rbArchive As System.Windows.Forms.RadioButton
    Friend WithEvents rbPcap As System.Windows.Forms.RadioButton
    Friend WithEvents cmnuMessages As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents SelectAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClearAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoadProfileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FilenameToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents rbAllMsg As System.Windows.Forms.RadioButton
    Friend WithEvents rbSelectMsg As System.Windows.Forms.RadioButton
    Friend WithEvents rbNoMsg As System.Windows.Forms.RadioButton

End Class
